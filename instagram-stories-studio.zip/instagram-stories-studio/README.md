# Instagram Stories Studio

Render finished, on-brand Instagram Stories from a JSON brief — with Instagram's safe zones
enforced in the layout and a sticker placement map generated alongside the frames.

**Brand tokens → brief JSON → HTML/CSS design system → headless Chromium → 2160×3840 PNG**,
with a natively rendered 1080×1920 set alongside it for posting.

There is a [sibling repo for carousels](https://github.com/danshah3000/instagram-carousel-studio).
Brand files are interchangeable between them.

---

## Why stories need their own tool

A story frame gets **three seconds and one thumb**, and the top and bottom of the canvas don't
belong to you:

| Band | Pixels of 1920 | Owner |
|---|---|---|
| 0–250 | top | Instagram — progress bars, avatar, account name, close button |
| **250–1620** | **middle** | **you** |
| 1620–1920 | bottom | Instagram — reply bar, share, react, and where stickers live |

Losing 550px of a 1920px canvas feels wasteful right up until you see a headline sitting under
someone's reply bar. The engine pads content into the middle band so it physically can't escape,
and the brand chip sits in the layout flow rather than absolutely positioned, so it can never
drift under the avatar row.

Those numbers are deliberately generous. Instagram's chrome moves between app versions and phone
notches; a design that fits exactly today breaks on the next release.

---

## Quick start

```bash
git clone https://github.com/danshah3000/instagram-stories-studio
cd instagram-stories-studio

npm install
npx playwright install chromium
pip install -r requirements.txt

python3 scripts/make_demo_assets.py      # placeholder brand + stand-in photos
node render.js briefs/demo.json
python3 scripts/contact_sheet.py out/demo
```

Add `SHOW_GUIDES=1` to also render a `guides/` set with the safe zones and sticker bands drawn
on top. Use it any time you change a layout.

---

## Stickers are reserved, not faked

When a frame declares a sticker, the bottom padding grows so the artwork leaves a genuinely clean
band, and the render writes `sticker-map.md`:

| # | frame | sticker | where |
|---|---|---|---|
| 03 | poll | **poll** | centre it **82% down** the frame — the empty band |

A rendered poll is a picture of a poll. It collects nothing. The drawn options exist so the real
sticker looks designed-in; you add the real one in the app after uploading. The map tells you
where the empty band was meant to be filled.

Empty space that looks accidental is a design failure. Empty space a sticker lands in perfectly
is the design.

---

## Set up your own brand

One command. It keys the mark off its background, traces it to smooth Bézier contours, writes it
out in four brand colours as SVG, derives the two background tones from `dark` + `primary`, and
writes the brand file.

```bash
python3 scripts/new_brand.py \
  --id northgate --name "Northgate Coffee" --wordmark NORTHGATE \
  --handle @northgatecoffee --tagline "Roasted in Leeds" \
  --primary '#2F5D50' --accent '#E0A458' --light '#FAF6F0' --dark '#1A1D1B' \
  --logo ~/brand/logo.png --logo-mode dark-on-light
```

Only `--id`, `--name`, `--primary` and `--accent` are required.

Every translucent value in the design system derives from those hexes — the renderer converts each
to an `r,g,b` triple and injects it as a CSS variable. A brand with no navy and no gold renders
correctly with no edits.

---

## Writing a brief

```json
{
  "brand": "northgate",
  "slug": "roast-day",
  "frames": [
    { "type": "hook", "image": "in/hero.jpg", "eyebrow": "Roast day",
      "headline": "We start _two hours_ before you do." },
    { "type": "poll", "headline": "Which do you reach for?",
      "options": ["Filter", "Espresso"], "sticker": { "type": "poll" } },
    { "type": "cta", "headline": "Want a bag?", "cta": "Tap the link",
      "sticker": { "type": "link", "note": "label it 'Shop now'" } }
  ]
}
```

Frame types: `hook` · `statement` · `list` · `steps` · `quote` · `stat` · `photo` · `poll` ·
`question` · `announcement` · `beforeafter` · `cta`.

Full schema: [`reference/frame-schema.md`](reference/frame-schema.md).

---

## Copy rules, tighter than the feed

- Headline: **7 words max**. Three seconds, arm's length, on a bright bus.
- Body: **20 words max**. If it needs more, it's two frames.
- List items: 6 words each, 3–4 items.
- Body type never below 38px — under about 34px, story text stops being read.

One sequencing note worth having: **put the interactive frame in the middle, not last.**
Engagement on frame 3 lifts delivery for the whole sequence, and by the final frame a large share
of the audience has already tapped away.

---

## Resolution

Authored at 1080×1920 CSS px, rendered at 2× → **2160×3840 masters**, which is true 4K in
portrait. The 1080×1920 posting set is a second native pass, not a downsample. `SCALE=3` gives
3240×5760 if a client asks, at roughly double the file size for no visible gain on a phone.

9:16 crops hard, so the renderer warns when a supplied photo is wider than that or under 2160px —
set `"focal": "70% 35%"` to keep the subject in frame.

---

## Working with an AI assistant

[`SKILL.md`](SKILL.md) is written as an agent skill: intake questions, sequencing and copy rules,
the render and verification loop. Point Claude Code (or any agent that reads repo instructions) at
this repo and it can run the whole thing.

[`MASTER-PROMPT.md`](MASTER-PROMPT.md) is the same system as a single copy-paste prompt, for use
in a chat with no repo access.

---

## Requirements

Node 18+, Python 3.9+, and Chromium via Playwright. Everything runs locally; nothing is uploaded.

## Licence

MIT.
