#!/usr/bin/env python3
"""Generate everything a fresh clone needs to render the demo: a placeholder logo,
a demo brand built through the real setup path, and two stand-in photos.

    python3 scripts/make_demo_assets.py
    node render.js briefs/demo.json

Nothing here is a real brand. It exists so `render.js` produces something on a clean
checkout, and so the logo pipeline (key off background -> trace to Bezier -> recolour)
is exercised end to end rather than described.
"""
import math, os, subprocess, sys
from PIL import Image, ImageDraw, ImageFilter

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CANVAS_W, CANVAS_H = 1080, 1920          # stories canvas, 9:16
MASTER_SCALE = 2                          # render.js default
PHOTO_W = CANVAS_W * MASTER_SCALE         # big enough not to trip the upscale warning
PHOTO_H = CANVAS_H * MASTER_SCALE


def make_logo(path):
    """An aperture mark — flat, high-contrast line art, exactly what the tracer expects."""
    S = 1200
    im = Image.new('RGB', (S, S), (250, 246, 240))
    d = ImageDraw.Draw(im)
    cx = cy = S / 2
    R = S * 0.36
    d.ellipse([cx - R, cy - R, cx + R, cy + R], outline=(22, 22, 20), width=32)
    r = R * 0.62
    for i in range(6):
        a0 = math.radians(60 * i - 24)
        a1 = math.radians(60 * i + 24)
        d.line([(cx + r * math.cos(a0), cy + r * math.sin(a0)),
                (cx + r * math.cos(a1), cy + r * math.sin(a1))],
               fill=(22, 22, 20), width=30)
    im.save(path)


def make_photo(path, warm=True, seed=1):
    """A synthetic landscape. Placeholder only — swap in real photography."""
    import random
    random.seed(seed)
    W, H = PHOTO_W, PHOTO_H
    im = Image.new('RGB', (W, H))
    d = ImageDraw.Draw(im)
    for y in range(H):
        t = y / H
        peak = max(0.0, 0.40 - abs(t - 0.40))
        if warm:
            r, g, b = 20 + 300 * peak, 28 + 215 * peak, 44 + 110 * peak
        else:
            r, g, b = 16 + 110 * peak, 26 + 150 * peak, 46 + 215 * peak
        d.line([(0, y), (W, y)], fill=(min(int(r), 255), min(int(g), 255), min(int(b), 255)))
    glow = Image.new('L', (W, H), 0)
    gd = ImageDraw.Draw(glow)
    gx, gy, gr = int(W * 0.6), int(H * 0.42), int(W * 0.24)
    gd.ellipse([gx - gr, gy - gr, gx + gr, gy + gr], fill=205)
    glow = glow.filter(ImageFilter.GaussianBlur(int(W * 0.12)))
    tint = Image.new('RGB', (W, H), (255, 206, 140) if warm else (150, 190, 235))
    im = Image.composite(tint, im, glow.point(lambda p: int(p * 0.85)))
    d = ImageDraw.Draw(im)
    for base, col in [(0.56, (14, 20, 30)), (0.66, (10, 15, 23)), (0.78, (6, 10, 16))]:
        pts, x = [(0, H)], 0
        while x <= W:
            pts.append((x, H * base + math.sin(x / (W / 6.0) + seed) * H * 0.035
                        + random.uniform(-H * 0.012, H * 0.012)))
            x += W // 20
        pts.append((W, H))
        d.polygon(pts, fill=col)
    im.filter(ImageFilter.GaussianBlur(0.6)).save(path, quality=92)


if __name__ == '__main__':
    os.makedirs(os.path.join(HERE, 'in'), exist_ok=True)
    tmp_logo = os.path.join(HERE, 'in', '_demo_logo.png')
    make_logo(tmp_logo)
    print('placeholder logo ->', tmp_logo)

    subprocess.run([sys.executable, os.path.join(HERE, 'scripts', 'new_brand.py'),
                    '--id', 'example', '--name', 'Example Studio', '--wordmark', 'EXAMPLE',
                    '--handle', '@example', '--tagline', 'A demo brand',
                    '--primary', '#2E6F6B', '--accent', '#D4633F',
                    '--light', '#F5F2EC', '--dark', '#1C1B1A',
                    '--logo', tmp_logo, '--logo-mode', 'dark-on-light',
                    '--wordmark-tracking', '0.30em'], check=True)

    make_photo(os.path.join(HERE, 'in', 'hero.jpg'), warm=True, seed=1)
    make_photo(os.path.join(HERE, 'in', 'close.jpg'), warm=False, seed=4)
    make_photo(os.path.join(HERE, 'in', 'before.jpg'), warm=False, seed=9)
    make_photo(os.path.join(HERE, 'in', 'after.jpg'), warm=True, seed=3)
    os.remove(tmp_logo)
    print('\ndemo photos -> in/hero.jpg, in/close.jpg, in/before.jpg, in/after.jpg')
    print('now run:  node render.js briefs/demo.json')
