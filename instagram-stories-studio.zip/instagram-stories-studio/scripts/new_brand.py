#!/usr/bin/env python3
"""Scaffold a brand for the studio in one command: extract + vectorise the logo,
derive the background colours, write brands/<id>.json.

  python3 scripts/new_brand.py \
      --id northgate --name "Northgate Coffee" --wordmark NORTHGATE \
      --handle @northgatecoffee --tagline "ROASTED IN LEEDS" \
      --primary '#2F5D50' --accent '#E0A458' --light '#FAF6F0' --dark '#1A1D1B' \
      --logo ~/brand/logo.png --logo-mode dark-on-light

Only --id, --name, --primary and --accent are strictly required; the rest have
sensible defaults. `ink` and `inkSoft` are derived from `dark` + `primary` unless
you pass them.

Without --logo, the brand file is written pointing at logo paths you can fill in
later — everything else still works.
"""
import argparse, json, os, subprocess, sys, colorsys

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def hex2rgb(h):
    h = h.lstrip('#')
    if len(h) == 3:
        h = ''.join(c * 2 for c in h)
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def rgb2hex(t):
    return '#%02X%02X%02X' % tuple(max(0, min(255, int(round(v)))) for v in t)


def derive_ink(dark, primary):
    """Deepest background: the brand's dark, pulled a little toward the primary hue
    and taken down. Keeps dark frames feeling like the brand rather than plain black."""
    dr, dg, db = hex2rgb(dark)
    pr, pg, pb = hex2rgb(primary)
    mix = [dr * 0.82 + pr * 0.18, dg * 0.82 + pg * 0.18, db * 0.82 + pb * 0.18]
    h, l, s = colorsys.rgb_to_hls(*[c / 255 for c in mix])
    l = max(0.028, l * 0.62)
    s = min(0.55, s * 1.25)
    return rgb2hex([c * 255 for c in colorsys.hls_to_rgb(h, l, s)])


def derive_ink_soft(ink, primary):
    """Lighter end of the background gradient — same hue, lifted."""
    ir, ig, ib = hex2rgb(ink)
    pr, pg, pb = hex2rgb(primary)
    mix = [ir * 0.72 + pr * 0.28, ig * 0.72 + pg * 0.28, ib * 0.72 + pb * 0.28]
    h, l, s = colorsys.rgb_to_hls(*[c / 255 for c in mix])
    l = min(0.20, max(0.075, l * 1.85))
    return rgb2hex([c * 255 for c in colorsys.hls_to_rgb(h, l, s)])


ap = argparse.ArgumentParser(formatter_class=argparse.RawDescriptionHelpFormatter,
                             description=__doc__)
ap.add_argument('--id', required=True)
ap.add_argument('--name', required=True)
ap.add_argument('--wordmark')
ap.add_argument('--tagline', default='')
ap.add_argument('--handle', default='')
ap.add_argument('--website', default='')
ap.add_argument('--services', default='')
ap.add_argument('--primary', required=True)
ap.add_argument('--accent', required=True)
ap.add_argument('--light', default='#F6F4EF')
ap.add_argument('--dark', default='#1D1F24')
ap.add_argument('--ink'); ap.add_argument('--ink-soft')
ap.add_argument('--font', default='Poppins', help='brand font family name')
ap.add_argument('--heading-weight', type=int, default=600)
ap.add_argument('--body-weight', type=int, default=400)
ap.add_argument('--wordmark-tracking', default='0.40em')
ap.add_argument('--eyebrow-tracking', default='0.28em')
ap.add_argument('--logo', help='image containing the logo mark')
ap.add_argument('--logo-mode', default='dark-on-light',
                choices=['dark-on-light', 'light-on-dark', 'warm'])
ap.add_argument('--logo-crop', help='L,T,R,B box isolating the mark in --logo')
ap.add_argument('--smooth', type=float, default=28.0, help='contour smoothing when tracing')
a = ap.parse_args()

ink = a.ink or derive_ink(a.dark, a.primary)
ink_soft = a.ink_soft or derive_ink_soft(ink, a.primary)

colors = {'primary': a.primary.upper(), 'accent': a.accent.upper(),
          'light': a.light.upper(), 'dark': a.dark.upper(),
          'ink': ink, 'inkSoft': ink_soft}

logo_paths = {k: f'assets/{a.id}_mark_{k}.svg' for k in ('accent', 'primary', 'light', 'dark')}

if a.logo:
    mask_prefix = os.path.join(HERE, 'assets', f'{a.id}_raw')
    cmd = [sys.executable, os.path.join(HERE, 'scripts', 'extract_logo.py'),
           a.logo, mask_prefix, '--mode', a.logo_mode,
           '--colors', 'mask=#FFFFFF']
    if a.logo_crop:
        cmd += ['--crop', a.logo_crop]
    subprocess.run(cmd, check=True)

    # extract_logo writes RGBA; trace wants a plain white-on-black mask
    from PIL import Image
    src = Image.open(f'{mask_prefix}_mask.png')
    Image.merge('L', (src.split()[3],)).save(f'{mask_prefix}_alpha.png')

    svg_out = os.path.join(HERE, 'assets', f'{a.id}_mark.svg')
    subprocess.run([sys.executable, os.path.join(HERE, 'scripts', 'trace_logo.py'),
                    f'{mask_prefix}_alpha.png', svg_out,
                    '--smooth', str(a.smooth), '--simplify', '1.0'], check=True)

    base = open(svg_out).read()
    for key, hexc in (('accent', colors['accent']), ('primary', colors['primary']),
                      ('light', colors['light']), ('dark', colors['dark'])):
        open(os.path.join(HERE, logo_paths[key]), 'w').write(
            base.replace('fill="currentColor"', f'fill="{hexc}"'))
    for f in (f'{mask_prefix}_mask.png', f'{mask_prefix}_alpha.png'):
        if os.path.exists(f):
            os.remove(f)
    print('logo vectorised ->', ', '.join(logo_paths.values()))
else:
    print('no --logo given: brand file written with placeholder logo paths')

brand = {
    'id': a.id, 'name': a.name,
    'wordmark': (a.wordmark or a.name).upper(),
    'tagline': a.tagline.upper(), 'handle': a.handle,
    'website': a.website, 'services': a.services,
    'colors': colors,
    'fonts': {
        'stack': f"'{a.font}','Poppins','Helvetica Neue',Arial,sans-serif",
        'headingWeight': a.heading_weight, 'bodyWeight': a.body_weight,
        'eyebrowWeight': 500,
    },
    'type': {'eyebrowTracking': a.eyebrow_tracking, 'wordmarkTracking': a.wordmark_tracking},
    'logo': logo_paths,
}

out = os.path.join(HERE, 'brands', f'{a.id}.json')
json.dump(brand, open(out, 'w'), indent=2)
print('wrote', out)
print(json.dumps(colors, indent=2))
print('\nnext:  node render.js briefs/<slug>.json      (set "brand": "%s" in the brief)' % a.id)
