#!/usr/bin/env python3
"""Trace a flat-colour logo mask into a smooth, resolution-independent SVG path.

usage: python3 scripts/trace_logo.py MASK.png OUT.svg [--smooth 6] [--simplify 0.6]
MASK.png must be a white-on-black alpha mask (see extract_logo.py).
"""
import argparse, numpy as np, cv2
from scipy.ndimage import gaussian_filter1d

ap = argparse.ArgumentParser()
ap.add_argument('mask'); ap.add_argument('out')
ap.add_argument('--smooth', type=float, default=6.0)
ap.add_argument('--simplify', type=float, default=0.6)
ap.add_argument('--upscale', type=int, default=4)
ap.add_argument('--minarea', type=float, default=60.0)
a = ap.parse_args()

m = cv2.imread(a.mask, cv2.IMREAD_GRAYSCALE)
if a.upscale > 1:
    m = cv2.resize(m, None, fx=a.upscale, fy=a.upscale, interpolation=cv2.INTER_CUBIC)
m = cv2.GaussianBlur(m, (0, 0), a.upscale * 1.2)
_, m = cv2.threshold(m, 127, 255, cv2.THRESH_BINARY)

cnts, hier = cv2.findContours(m, cv2.RETR_CCOMP, cv2.CHAIN_APPROX_NONE)
print('contours found:', len(cnts))

def catmull_to_bezier(P):
    """closed Catmull-Rom through P -> cubic bezier path data"""
    n = len(P)
    d = ['M %.2f %.2f' % (P[0][0], P[0][1])]
    for i in range(n):
        p0 = P[(i - 1) % n]; p1 = P[i]; p2 = P[(i + 1) % n]; p3 = P[(i + 2) % n]
        c1 = (p1[0] + (p2[0] - p0[0]) / 6.0, p1[1] + (p2[1] - p0[1]) / 6.0)
        c2 = (p2[0] - (p3[0] - p1[0]) / 6.0, p2[1] - (p3[1] - p1[1]) / 6.0)
        d.append('C %.2f %.2f %.2f %.2f %.2f %.2f' % (c1[0], c1[1], c2[0], c2[1], p2[0], p2[1]))
    d.append('Z')
    return ' '.join(d)

paths, kept = [], 0
for c in cnts:
    if cv2.contourArea(c) < a.minarea * (a.upscale ** 2):
        continue
    pts = c[:, 0, :].astype(np.float64)
    # periodic smoothing kills the mockup-lighting wobble in the source bitmap
    pts[:, 0] = gaussian_filter1d(pts[:, 0], a.smooth, mode='wrap')
    pts[:, 1] = gaussian_filter1d(pts[:, 1], a.smooth, mode='wrap')
    approx = cv2.approxPolyDP(pts.astype(np.float32).reshape(-1, 1, 2),
                              a.simplify * a.upscale, True)[:, 0, :]
    if len(approx) < 4:
        continue
    paths.append(catmull_to_bezier(approx)); kept += 1

xs = [v for p in paths for v in []]  # bbox from mask instead
ys, xs = np.where(m > 0)
x0, x1, y0, y1 = xs.min(), xs.max(), ys.min(), ys.max()
w, h = float(x1 - x0 + 1), float(y1 - y0 + 1)

svg = f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="{x0} {y0} {w:.0f} {h:.0f}" width="{w:.0f}" height="{h:.0f}">
  <path fill="currentColor" fill-rule="evenodd" d="{' '.join(paths)}"/>
</svg>'''
open(a.out, 'w').write(svg)
print('kept', kept, 'subpaths ->', a.out, f'({w:.0f}x{h:.0f})')
