#!/usr/bin/env python3
"""Pull a flat-colour logo mark off its background into transparent, re-colourable PNGs.

usage:
  python3 scripts/extract_logo.py SOURCE.png OUTPREFIX --mode dark-on-light
  python3 scripts/extract_logo.py SOURCE.png OUTPREFIX --mode light-on-dark
  python3 scripts/extract_logo.py SOURCE.png OUTPREFIX --mode warm   # gold/orange art
  ... optional: --crop L,T,R,B   --colors name=#RRGGBB,name=#RRGGBB

Writes OUTPREFIX_<name>.png for each colour, 1200px wide, clean anti-aliased edges.
"""
import sys, argparse
import numpy as np
from PIL import Image, ImageFilter

ap = argparse.ArgumentParser()
ap.add_argument('src'); ap.add_argument('outprefix')
ap.add_argument('--mode', default='dark-on-light',
                choices=['dark-on-light', 'light-on-dark', 'warm'])
ap.add_argument('--crop', default=None, help='L,T,R,B pixel box to isolate the mark first')
ap.add_argument('--colors', default='accent=#C8A45A,white=#FFFFFF,primary=#215F9B,dark=#1D1F24')
ap.add_argument('--width', type=int, default=1200)
a = ap.parse_args()

im = Image.open(a.src).convert('RGB')
if a.crop:
    im = im.crop(tuple(int(v) for v in a.crop.split(',')))
arr = np.asarray(im).astype(np.int16)
R, G, B = arr[..., 0], arr[..., 1], arr[..., 2]

if a.mode == 'dark-on-light':
    mask = (arr.mean(axis=2) < 130)
elif a.mode == 'light-on-dark':
    mask = (arr.mean(axis=2) > 140)
else:  # warm / gold line art on any background
    mask = (R > 110) & (R - B > 45) & (G > 80)

m = Image.fromarray((mask * 255).astype(np.uint8), 'L').filter(ImageFilter.MedianFilter(3))
box = m.getbbox()
if not box:
    sys.exit('nothing matched — try a different --mode or --crop')
m = m.crop(box)

# upscale → blur → re-threshold → downscale = clean anti-aliased edges
big = m.resize((m.width*3, m.height*3), Image.LANCZOS).filter(ImageFilter.GaussianBlur(4))
big = Image.fromarray(np.clip((np.asarray(big).astype(np.float32)-118)*6+128, 0, 255).astype(np.uint8), 'L')
h = round(a.width * m.height / m.width)
mask_img = big.resize((a.width, h), Image.LANCZOS)

for pair in a.colors.split(','):
    name, hexc = pair.split('=')
    rgb = tuple(int(hexc.lstrip('#')[i:i+2], 16) for i in (0, 2, 4))
    layer = Image.new('RGBA', mask_img.size, rgb + (0,))
    layer.putalpha(mask_img)
    out = f'{a.outprefix}_{name}.png'
    layer.save(out)
    print('wrote', out, layer.size)
