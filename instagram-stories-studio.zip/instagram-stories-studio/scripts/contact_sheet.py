#!/usr/bin/env python3
"""Build a contact sheet from a rendered story set so the frames can be reviewed together.
usage: python3 scripts/contact_sheet.py out/<slug> [cols]"""
import sys, glob, os
from PIL import Image

d = sys.argv[1]
cols = int(sys.argv[2]) if len(sys.argv) > 2 else 4
files = sorted(glob.glob(os.path.join(d, '*.png')))
files = [f for f in files if not os.path.basename(f).startswith('_')
         and 'contact' not in os.path.basename(f)]
if not files:
    sys.exit('no slides found in ' + d)
ims = [Image.open(f) for f in files]
w, h = 236, 420
rows = (len(ims) + cols - 1) // cols
pad = 12
sheet = Image.new('RGB', (cols*w + (cols+1)*pad, rows*h + (rows+1)*pad), (26, 26, 28))
for i, im in enumerate(ims):
    x = (i % cols)*(w+pad)+pad
    y = (i // cols)*(h+pad)+pad
    sheet.paste(im.convert('RGB').resize((w, h), Image.LANCZOS), (x, y))
out = os.path.join(d, 'contact-sheet.png')
sheet.save(out)

# every slide must be the same size, 4:5, and a whole multiple of the 1080x1350 canvas
sizes = {im.size for im in ims}
base = ims[0].size
problems = []
if len(sizes) > 1:
    problems.append('mixed sizes: ' + ', '.join(f'{w}x{h}' for w, h in sorted(sizes)))
else:
    w, h = base
    if round(w / 1080, 3) != round(h / 1920, 3):
        problems.append(f'{w}x{h} is not 9:16')
    elif w % 1080:
        problems.append(f'{w}x{h} is not a whole multiple of 1080x1350')
print('frames:', len(ims), '|', f'{base[0]}x{base[1]}', '| scale:', round(base[0]/1080, 2))
print('checks:', '; '.join(problems) if problems else 'ok')
print(out)
