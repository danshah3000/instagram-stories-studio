# Design rules

Why story frames look the way they do, and which knobs are safe to turn per brand.

## Resolution

Authored in 1080 × 1920 CSS pixels, rendered at 2× device scale → **2160 × 3840 masters**, which is
true 4K in portrait. Every measurement below is in CSS pixels; multiply by 2 for the master.
`SCALE=3` gives 3240 × 5760 if a client wants it, at roughly double the file size for no visible
gain on a phone.

The 1080 posting set is a second native pass, not a downsample — text hinting is better when the
browser lays out at the target size.

Two things this resolution demands:

- **Vector logos.** A mark lifted off a brand board as a PNG is soft at 2×. `scripts/new_brand.py`
  traces it to Bézier contours automatically.
- **Grain scales inversely.** The noise overlay is sized `140px / scale`, keeping it 1:1 with device
  pixels. Otherwise it reads as blur rather than texture.

## The zone budget — the whole reason stories differ

| Band | Pixels | Owner |
|---|---|---|
| 0–250 | top | Instagram: progress bars, avatar, name, close |
| 250–1620 | middle | you |
| 1620–1920 | bottom | Instagram: reply bar, share, react — and stickers |

The numbers are deliberately generous. Instagram's chrome moves between app versions and phone
notches; a design that fits exactly today breaks on the next release. Losing 550px of a 1920px
canvas feels wasteful until you see a headline sitting under someone's reply bar.

The brand chip sits **in the stage's flow**, not absolutely positioned — so it can never drift under
the avatar row, and the body can never grow into it.

When a frame declares a sticker, the stage's bottom padding grows to clear the band at 1450–1690.
That band is left visibly empty on purpose. Empty space that looks accidental is a design failure;
empty space that a sticker lands in perfectly is the design.

## Bigger type, less of it

A feed post gets studied. A story gets three seconds, one thumb, often outdoors. So:

- Headlines run 80–116px against the carousel's 66–104px.
- Body copy is 38px minimum. Below ~34px, story text stops being read.
- The fit pass caps growth at 1.18× on text frames and 1.10× over photos, then aligns the block —
  centred frames sit at 45% rather than 50%, because the bottom band belongs to Instagram and dead
  centre reads low.

Long copy doesn't overflow, it shrinks. If a frame's type is visibly smaller than its neighbours,
that's the system telling you to cut words.

## Heavier scrims

The photo scrim is stronger than the feed's — dark at the top through 22%, easing through the
middle, and near-solid by 82%. Stories are viewed at full brightness outdoors, and unlike a feed
post nobody stops to squint. Every photo also gets `saturate(.88) contrast(1.06)` and a soft-light
duotone wash in the brand's primary + accent, which is why photos from three different phones still
look like one sequence.

## Everything derives from the brand file

The renderer converts each brand hex to an `r,g,b` triple and injects it as a CSS variable, so every
translucent value in the system — scrims, body copy opacity, card fills, borders — follows the
brand. A brand with no navy and no gold renders correctly with no edits. This is the difference
between a design system and a template with one brand hardcoded into its rgba values.

`scripts/new_brand.py` derives the two background colours rather than asking for them: `ink` is the
brand's dark pulled 18% toward the primary hue and taken down in lightness; `inkSoft` is that same
hue lifted. It means dark frames feel like the brand rather than generic black, from four inputs.

## Per-brand knobs

Safe to change in `brands/<id>.json`:

- `colors.*` — all six
- `fonts.stack` and the three weights
- `type.wordmarkTracking` — wide tracking reads premium on a 4-letter wordmark and awful on a
  10-letter one. A four-letter wordmark carries `0.42em`; `NORTHGATE` wants `0.24em`.
- `type.eyebrowTracking`

Everything else is shared on purpose. A brand needing genuinely different geometry — serif display,
editorial grid, maximalist palette — gets a second theme class in `engine.css`, not a forked
renderer.

## Fonts

The stack lists the real brand font first and falls back. If it isn't installed in the render
environment the fallback is used and output stays consistent, just not exact. For true fidelity,
install the brand's font files and confirm with a test render before shipping.
