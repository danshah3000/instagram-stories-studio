# Frame schema

One JSON file per sequence, in `briefs/<slug>.json`. Render with `node render.js briefs/<slug>.json`.

## Top level

| key | type | notes |
|---|---|---|
| `brand` | string | filename in `brands/` without `.json` |
| `slug` | string | output folder and filenames, kebab-case |
| `theme` | `"dark"` \| `"light"` | default for every frame; frames can override |
| `handle` | string | overrides the brand's handle in the chip |
| `showHandle` | boolean | `false` shows only the wordmark |
| `scale` | number | master scale. Default `2` → 2160×3840. A 1080×1920 set is always written to `instagram-1080/`. |
| `captions` | string[] | one per frame, written to `captions.txt` — notes for whoever posts |
| `frames` | array | 3–7 frame objects, in order |

## Shared frame keys

| key | notes |
|---|---|
| `type` | see below |
| `theme` | override the sequence theme for this frame |
| `image` | photo path, rendered full-bleed |
| `focal` | CSS `object-position`, e.g. `"70% 35%"` — matters more than in the feed, 9:16 crops hard |
| `softScrim` | flatter, heavier darkening for busy photos |
| `chip` | `false` removes the brand chip (use on the final sign-off frame) |
| `watermark` | `false` removes the ghost mark |
| `eyebrow` | 1–3 words, all caps, accent colour, leading rule |
| `sticker` | `{ "type": "poll"\|"question"\|"link"\|"quiz"\|"slider"\|"countdown"\|"none", "note": "…" }` — reserves the band and adds a row to the sticker map |

## Inline formatting

- `*word*` → accent colour
- `_word_` → light weight

One per headline at most.

## Frame types

### `hook`
`eyebrow`, `headline`, `sub`, `cue`, `image`.
Bottom-aligned over a photo. The only frame most people see. `cue: false` removes the tap hint.

### `statement`
`eyebrow`, `headline`, `body`, `card`.
`card` is a bordered callout — good for the one line you want screenshotted.

### `list`
`eyebrow`, `headline`, `items: string[]`, `numbered: bool`.
3–4 items, 6 words each. Longer and the fit pass shrinks it below story-legible.

### `steps`
`eyebrow`, `headline`, `items: [{ t, d }]`.
Three steps is the ceiling on a story frame. Four works only with very short detail lines.

### `quote`
`quote`, `attrib`. Under 12 words.

### `stat`
`eyebrow`, `value`, `label`, `body`. `value` set huge in the accent colour.

### `photo`
`image`, `eyebrow`, `headline`, `caption`. A breather — photo with one line over it.

### `poll`
`eyebrow`, `headline`, `body`, `options: [string, string]`, `sticker`.
Draws the two options as pills so the real sticker looks designed-in. **The drawn options collect
nothing** — add the real poll sticker in-app, with the same two words.

### `question`
`eyebrow`, `headline`, `body`, `placeholder`, `sticker`.
Draws a dashed answer box under the prompt. Same rule: the real sticker goes on top.

### `announcement`
`eyebrow`, `headline`, `details: [{ k, v }]`, `body`.
`details` renders as a label/value stack — date, time, place, price.

### `beforeafter`
`images: [before, after]`, `labels: [string, string]`, `eyebrow`, `headline`, `caption`.
Stacked halves with an accent divider; labels flank it, clear of Instagram's chrome.

### `cta`
`headline`, `body`, `cta`, `image`, `sticker`.
Centred logo lockup, wordmark, tagline, then one ask. Set `"chip": false` so the mark isn't twice
on the frame.

## Worked example

```json
{
  "brand": "example",
  "slug": "demo",
  "theme": "dark",
  "handle": "@example",
  "frames": [
    { "type": "hook", "image": "in/hero.jpg", "focal": "60% 40%",
      "eyebrow": "Shoot day",
      "headline": "We start _two hours_ before you do.",
      "sub": "Here's what happens before anyone picks up a camera.",
      "cue": "Keep watching" },

    { "type": "statement", "eyebrow": "First light",
      "headline": "The location decides *half* the film.",
      "body": "We walk it at the exact hour we'll be filming.",
      "card": "Same room, three hours apart, is two different films." },

    { "type": "poll", "eyebrow": "Quick one",
      "headline": "What matters more to you?",
      "options": ["The way it looks", "The way it sounds"],
      "sticker": { "type": "poll", "note": "use the same two options as the artwork" } },

    { "type": "beforeafter", "images": ["in/before.jpg", "in/after.jpg"],
      "labels": ["Straight off camera", "Graded"],
      "eyebrow": "Same frame",
      "headline": "Grading is where it becomes yours." },

    { "type": "cta", "image": "in/close.jpg", "softScrim": true, "chip": false,
      "headline": "Planning something?",
      "body": "Tell us the story you want to tell.",
      "cta": "Tap the link",
      "sticker": { "type": "link", "note": "label it 'Book a call' — two words max" } }
  ],
  "captions": [
    "Shoot day starts early.",
    "Location first.",
    "Poll: looks or sound?",
    "Before and after the grade.",
    "Link sticker to the booking page."
  ]
}
```
