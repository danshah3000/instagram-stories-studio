---
name: stories-studio
description: Turn a topic and a few photos into a finished, on-brand Instagram Stories sequence — 2160x3840 masters plus a ready-to-post 1080x1920 set, with a sticker placement map. Works for any brand from a one-command setup. Use when the user asks for Instagram stories, a story sequence, story frames, IG stories, or says "make me some stories about X".
---

# Stories Studio

Post-ready Instagram Stories that look like one designer made the whole sequence — for any brand,
not one.

Same pipeline as a carousel, different physics: **brand tokens → brief JSON → HTML/CSS design
system → Chromium screenshot → 2160×3840 PNG**, with a native 1080×1920 set alongside it and a
sticker map telling you exactly where to drop the real Instagram stickers.

Stories are not tall carousels. A frame gets **three seconds and one thumb**. The copy is shorter,
the type is bigger, and the top and bottom of the canvas belong to Instagram, not to you.

---

## 0. Before anything else — run the intake

**Never start rendering from a one-line request.** Ask, get answers, then build. One round.

1. **Brand** — which brand is this for? (If it has no `brands/<id>.json` yet, jump to §1 first.)
2. **Topic + angle** — what is this sequence actually doing? Teaching, announcing, selling, showing
   process, asking?
3. **Frame count** — 3 to 7. Default 5. More than 7 and people tap out.
4. **Goal** — replies, link taps, poll votes, profile visits, bookings.
5. **Images** — *ask for them explicitly.* "Send the photos you want used, or tell me which folder
   to pull from." Ask what each shows, and warn that stories crop to 9:16 — a wide landscape shot
   loses its edges.
6. **Stickers** — poll, question, link, quiz, countdown, slider, or none? Link stickers need an
   account that has them.
7. **Timing** — posting now, or scheduled? Anything time-sensitive on the frames (a date, a
   deadline, "today only") that will go stale?

If the session is unattended, choose sensible defaults, say so at the top of the reply, and carry on.

Then **show the frame-by-frame outline before rendering** — one line each, plus which photo and
which sticker lands where. Get a yes, then render.

---

## 1. Set the brand up — one command

Brand tokens live in `brands/<id>.json`. If the brand exists, load it and move on.

If it doesn't, and you have their logo and colours:

```bash
python3 scripts/new_brand.py \
  --id northgate --name "Northgate Coffee" --wordmark NORTHGATE \
  --handle @northgatecoffee --tagline "Roasted in Leeds" \
  --primary '#2F5D50' --accent '#E0A458' --light '#FAF6F0' --dark '#1A1D1B' \
  --logo ~/brand/logo.png --logo-mode dark-on-light
```

That one command keys the mark off its background, traces it to smooth Bézier contours, writes it
out in four brand colours as SVG, derives the two background colours from `dark` + `primary`, and
writes the brand file. `--logo-mode` is `dark-on-light`, `light-on-dark`, or `warm` (gold/orange
line art); add `--logo-crop L,T,R,B` when the mark sits inside a larger brand board.

Only `--id`, `--name`, `--primary` and `--accent` are required. Without `--logo` you still get a
working brand file with placeholder logo paths.

**Show the user the derived tokens and the traced mark before using them.** Never invent a brand's
colours or logo — if you can't find them, ask.

Brand files are shared with the carousel studio. A file written for either one works in both: the
renderer accepts logo variants named semantically (`accent`/`primary`/`light`/`dark`) or by the
brand's own colour names (`gold`/`blue`/`white`/`charcoal`). Copy the JSON and the SVGs across and
a brand set up once serves both formats.

---

## 2. Write the brief

Create `briefs/<slug>.json`. Full schema in `reference/frame-schema.md`.

```json
{
  "brand": "northgate",
  "slug": "roast-day",
  "theme": "dark",
  "handle": "@northgatecoffee",
  "frames": [
    { "type": "hook", "image": "in/hero.jpg", "eyebrow": "Roast day",
      "headline": "We start _two hours_ before you do.", "sub": "One line of context." },
    { "type": "statement", "headline": "The bean decides *half* of it.", "body": "…" },
    { "type": "poll", "headline": "Which do you reach for?",
      "options": ["Filter", "Espresso"], "sticker": { "type": "poll" } },
    { "type": "cta", "image": "in/close.jpg", "headline": "Want a bag?",
      "cta": "Tap the link", "sticker": { "type": "link", "note": "label it 'Shop now'" } }
  ]
}
```

`*word*` renders in the accent colour, `_word_` in the light weight. One per headline, at most.

### Frame types

`hook` · `statement` · `list` · `steps` · `quote` · `stat` · `photo` · `poll` · `question` ·
`announcement` · `beforeafter` · `cta`

### Sequencing that holds attention

| Frame | Job |
|---|---|
| 1 | Stop the tap. A photo and a claim, a number, or a tension. Never a logo splash. |
| 2 | Pay it off — the thing you promised, immediately. Don't make them wait. |
| middle | One idea per frame. Put the interactive frame here, not last. |
| last | The ask. One ask. Link or DM, not both. |

Put the poll or question **in the middle**, not at the end — engagement on frame 3 lifts the whole
sequence's delivery, and by the last frame half the audience has gone.

### Copy rules — tighter than a carousel

- Headline: **7 words max**. Three seconds, arm's length, on a bright bus.
- Body: **20 words max**. If it needs more, it's two frames.
- List items: 6 words each, 3–4 items.
- Eyebrow: 1–3 words.
- No emoji in the artwork. Put them in stickers or the reply, where they're tappable.

---

## 3. Prepare the images

- Copy or stage photos into `in/`. Never reference a path that might disappear.
- **9:16 crops hard.** A landscape photo loses both edges. The renderer warns when a supplied image
  is wider than 9:16; set `"focal": "70% 35%"` to keep the subject, or ask for a vertical original.
- Photos are full-bleed and get a heavier scrim than the feed — stories are read fast, on bright
  screens, often outdoors. Don't pre-grade them; the duotone wash is doing that job.
- `beforeafter` takes `"images": [before, after]` and stacks them with the labels flanking the
  divider.

---

## 4. Render

```bash
node render.js briefs/<slug>.json
```

- `out/<slug>/` — **2160×3840 masters** (true 4K portrait).
- `out/<slug>/instagram-1080/` — **1080×1920**, natively rendered. This is what gets posted.
- `out/<slug>/sticker-map.md` — where to place each sticker, as a % down the frame.
- `captions.txt` when the brief carries per-frame captions.

`SCALE=3 node render.js …` for bigger masters. `SHOW_GUIDES=1 node render.js …` also writes a
`guides/` set with the safe zones and sticker bands drawn on — use it whenever you change a layout.

---

## 5. The zones — the part that ruins stories

| Band | Pixels (of 1920) | What's there |
|---|---|---|
| Top | 0–250 | Progress bars, avatar, account name, close button |
| **Middle** | **250–1620** | **Yours** |
| Bottom | 1620–1920 | Reply bar, share, react — and where stickers want to live |

The engine enforces this: content is padded into the middle band and can't escape it. When a frame
declares a sticker, the bottom padding grows so the artwork leaves that band deliberately clean.

**Render the sticker, don't fake it.** A drawn poll is a picture of a poll — it collects nothing.
The artwork's poll options exist to make the real sticker feel designed-in; the real one goes on top
in the app. The sticker map tells the user where.

---

## 6. Verify before delivering — non-negotiable

```bash
SHOW_GUIDES=1 node render.js briefs/<slug>.json
python3 scripts/contact_sheet.py out/<slug>
python3 scripts/contact_sheet.py out/<slug>/guides
```

Look at both sheets, then open frame 1 and the densest frame at full size.

- [ ] Every master is 2160×3840, every companion 1080×1920.
- [ ] Nothing readable sits in the red bands on the guides sheet.
- [ ] Sticker frames have a genuinely empty band where the green box is.
- [ ] No photo triggered an upscale or aspect warning you ignored.
- [ ] Frame 1 works with the sound off and no context.
- [ ] No frame's type shrank noticeably smaller than its neighbours — if it did, cut copy.
- [ ] Names, prices, dates, times exactly as given. Check the time zone on anything scheduled.

---

## 7. Deliver

- Send the **1080 set** in order, in one go — that's what gets posted.
- Send `sticker-map.md` with it, or paste its table into the message. Without it the user has to
  guess where the empty bands were meant to be.
- Write both sets into the user's connected folder if they have one.
- Masters run 4–7MB each; mind transfer limits and commit in batches if needed.
- Say which frames need a sticker added in-app before posting.

---

## Design system

Held in `engine.css`, and every colour in it derives from the brand file — the renderer converts
each brand hex to an `r,g,b` triple, so a brand with no navy and no gold still renders correctly.
Don't restyle per sequence. If something needs to change, change it in the design system so every
future sequence inherits it.

Details in `reference/design-rules.md`.
