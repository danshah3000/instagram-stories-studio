#!/usr/bin/env node
/* ============================================================
   STORIES STUDIO — renderer
   usage: node render.js briefs/<slug>.json [outDir]
   env:   SCALE=2         master scale (default 2 -> 2160x3840)
          SHOW_GUIDES=1   also write a guides/ set with safe zones drawn on
   ============================================================ */
const fs = require('fs');
const path = require('path');
const { chromium } = require('playwright');

const ROOT = __dirname;
const W = 1080, H = 1920;

// Instagram chrome. Measured against the current app; generous on purpose.
const SAFE_TOP = 250;      // progress bars, avatar, name, close
const SAFE_BOTTOM = 300;   // reply bar, share, react
const GUTTER = 88;
// where an interactive sticker sits when a frame declares one
const STICKER_TOP = 1450, STICKER_H = 240;

const esc = s => String(s == null ? '' : s)
  .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
const rich = s => esc(s)
  .replace(/\*(.+?)\*/g, '<em>$1</em>')
  .replace(/_(.+?)_/g, '<span class="lightword">$1</span>');
const fileUrl = p => 'file://' + path.resolve(p);

/* hex -> "r,g,b" so every rgba() in the design system follows the brand,
   instead of being hardcoded to one palette */
function rgb(hex) {
  const h = String(hex || '#000').replace('#','').trim();
  const f = h.length === 3 ? h.split('').map(c=>c+c).join('') : h;
  const n = parseInt(f.slice(0,6), 16);
  return `${(n>>16)&255},${(n>>8)&255},${n&255}`;
}

function headSize(text, base) {
  const L = String(text || '').length;
  if (L <= 18) return base;
  if (L <= 32) return Math.round(base * 0.86);
  if (L <= 50) return Math.round(base * 0.72);
  if (L <= 72) return Math.round(base * 0.60);
  return Math.round(base * 0.50);
}

function photo(f) {
  if (!f.image) return '';
  return `<div class="photo${f.softScrim ? ' soft' : ''}" style="--focal:${f.focal || 'center'}">
    <img src="${fileUrl(f.image)}" alt=""><div class="wash"></div></div>`;
}

function chip(brand, cfg, f) {
  if (f.chip === false) return '';
  const logo = (f.theme === 'light') ? brand.logo.primary : brand.logo.accent;
  const handle = cfg.showHandle === false ? '' :
    `<div class="handle">${esc(cfg.handle || brand.handle)}</div>`;
  return `<div class="chip">
    <img src="${fileUrl(path.join(ROOT, logo))}" alt="">
    <div class="wm">${esc(brand.wordmark)}</div>${handle}
  </div>`;
}

function frameBody(f, brand) {
  const eyebrow = f.eyebrow
    ? `<div class="eyebrow"><span class="rule"></span>${esc(f.eyebrow)}</div>` : '';

  switch (f.type) {
    case 'hook':
      return { cls:'bottom', html:`${eyebrow}
        <h1 class="headline" style="font-size:${headSize(f.headline,116)}px">${rich(f.headline)}</h1>
        ${f.sub ? `<p class="sub">${rich(f.sub)}</p>` : ''}
        ${f.cue !== false ? `<div class="swipe">${esc(f.cue || 'Keep watching')}<span class="arrow"></span></div>` : ''}` };

    case 'statement':
      return { cls:'center', html:`${eyebrow}
        <h2 class="headline" style="font-size:${headSize(f.headline,104)}px">${rich(f.headline)}</h2>
        ${f.body ? `<p class="body">${rich(f.body)}</p>` : ''}
        ${f.card ? `<div class="card">${rich(f.card)}</div>` : ''}` };

    case 'list': {
      const items = (f.items||[]).map((t,i)=> f.numbered
        ? `<li><span class="num">${String(i+1).padStart(2,'0')}</span><span>${rich(t)}</span></li>`
        : `<li><span class="bullet"></span><span>${rich(t)}</span></li>`).join('');
      return { cls:'center', html:`${eyebrow}
        <h2 class="headline" style="font-size:${headSize(f.headline,84)}px">${rich(f.headline)}</h2>
        <ul class="list">${items}</ul>` };
    }

    case 'steps': {
      const items = (f.items||[]).map((it,i)=>`
        <div class="step"><div class="idx">${String(i+1).padStart(2,'0')}</div>
        <div><div class="t">${rich(it.t)}</div>${it.d?`<div class="d">${rich(it.d)}</div>`:''}</div></div>`).join('');
      return { cls:'center', html:`${eyebrow}
        <h2 class="headline" style="font-size:${headSize(f.headline,80)}px">${rich(f.headline)}</h2>
        <div class="steps">${items}</div>` };
    }

    case 'quote':
      return { cls:'center', html:`<div class="quotemark">&ldquo;</div>
        <p class="quote">${rich(f.quote)}</p>
        ${f.attrib?`<div class="attrib">${esc(f.attrib)}</div>`:''}` };

    case 'stat':
      return { cls:'center', html:`${eyebrow}
        <div class="stat">${rich(f.value)}</div>
        <div class="statlabel">${rich(f.label)}</div>
        ${f.body?`<p class="body">${rich(f.body)}</p>`:''}` };

    case 'photo':
      return { cls:'bottom', html:`${eyebrow}
        ${f.headline?`<h2 class="headline" style="font-size:${headSize(f.headline,92)}px">${rich(f.headline)}</h2>`:''}
        ${f.caption?`<p class="sub">${rich(f.caption)}</p>`:''}` };

    case 'poll': {
      const opts = (f.options||['Yes','No']).map((o,i)=>
        `<div class="option${i===0?' filled':''}">${esc(o)}</div>`).join('');
      return { cls:'center', center:true, html:`${eyebrow}
        <h2 class="headline" style="font-size:${headSize(f.headline,88)}px">${rich(f.headline)}</h2>
        ${f.body?`<p class="body">${rich(f.body)}</p>`:''}
        <div class="options">${opts}</div>` };
    }

    case 'question':
      return { cls:'center', center:true, html:`${eyebrow}
        <h2 class="headline" style="font-size:${headSize(f.headline,88)}px">${rich(f.headline)}</h2>
        ${f.body?`<p class="body">${rich(f.body)}</p>`:''}
        <div class="prompt">${esc(f.placeholder || 'Your answer goes here')}</div>` };

    case 'announcement': {
      const rows = (f.details||[]).map(d=>
        `<div class="row"><span class="k">${esc(d.k)}</span><span>${rich(d.v)}</span></div>`).join('');
      return { cls:'center', html:`${eyebrow}
        <h2 class="headline" style="font-size:${headSize(f.headline,96)}px">${rich(f.headline)}</h2>
        <div class="when">${rows}</div>
        ${f.body?`<p class="body">${rich(f.body)}</p>`:''}` };
    }

    case 'beforeafter':
      return { cls:'bottom', html:`${eyebrow}
        ${f.headline?`<h2 class="headline" style="font-size:${headSize(f.headline,84)}px">${rich(f.headline)}</h2>`:''}
        ${f.caption?`<p class="sub">${rich(f.caption)}</p>`:''}` };

    case 'cta':
      return { cls:'center', center:true, html:`<div class="signoff">
        <img src="${fileUrl(path.join(ROOT, f.theme==='light'?brand.logo.primary:brand.logo.accent))}" alt="">
        <div class="wm">${esc(brand.wordmark)}</div>
        <div class="tag">${esc(brand.tagline)}</div>
        ${f.headline?`<div class="hl">${rich(f.headline)}</div>`:''}
        ${f.body?`<div class="bd">${rich(f.body)}</div>`:''}
        ${f.cta?`<div class="pill">${esc(f.cta)}</div>`:''}
      </div>` };

    default:
      throw new Error('unknown frame type: ' + f.type);
  }
}

function splitPhotos(f) {
  if (f.type !== 'beforeafter') return '';
  const [a, b] = f.images || [];
  if (!a || !b) throw new Error('beforeafter needs "images": [before, after]');
  const labs = f.labels || ['Before', 'After'];
  return `<div class="split">
    <div><img src="${fileUrl(a)}" alt=""><div class="tag">${esc(labs[0])}</div></div>
    <div class="divider"></div>
    <div><img src="${fileUrl(b)}" alt=""><div class="tag">${esc(labs[1])}</div></div>
  </div>`;
}

function guides(f) {
  const st = f.sticker && f.sticker.type && f.sticker.type !== 'none';
  return `<div class="guides">
    <div class="band top"></div><div class="lab" style="top:${SAFE_TOP-34}px;left:16px">IG chrome — ${SAFE_TOP}px</div>
    <div class="band bottom"></div><div class="lab" style="bottom:${SAFE_BOTTOM+8}px;left:16px">IG chrome — ${SAFE_BOTTOM}px</div>
    <div class="gutter l"></div><div class="gutter r"></div>
    ${st ? `<div class="sticker" style="top:${STICKER_TOP}px;left:${GUTTER}px;right:${GUTTER}px;height:${STICKER_H}px"></div>
      <div class="lab" style="top:${STICKER_TOP-34}px;left:${GUTTER}px">${esc(f.sticker.type)} sticker</div>` : ''}
  </div>`;
}

function buildHTML(f, i, n, brand, cfg, css) {
  const theme = f.theme || cfg.theme || 'dark';
  const b = frameBody({ ...f, theme }, brand);
  const hasSticker = !!(f.sticker && f.sticker.type && f.sticker.type !== 'none');
  const padBottom = hasSticker ? (H - STICKER_TOP + 50) : SAFE_BOTTOM;

  const wantGhost = f.watermark !== false && !f.image && f.type !== 'beforeafter' && f.type !== 'cta';
  const ghost = wantGhost
    ? `<img class="ghost ${i % 2 ? 'tl' : ''}" src="${fileUrl(path.join(ROOT,
        theme === 'light' ? brand.logo.primary : brand.logo.accent))}" alt="">`
    : '';

  const fitCap = (f.image || f.type === 'beforeafter') ? 1.10 : (f.type === 'cta' ? 1.06 : 1.18);
  const c = brand.colors, ft = brand.fonts;

  return `<!doctype html><html><head><meta charset="utf-8"><style>
:root{
  --font:${ft.stack};
  --ink:${c.ink}; --inkSoft:${c.inkSoft}; --paper:${c.light};
  --light:${c.light}; --dark:${c.dark}; --accent:${c.accent}; --primary:${c.primary};
  --ink-rgb:${rgb(c.ink)}; --light-rgb:${rgb(c.light)}; --dark-rgb:${rgb(c.dark)};
  --accent-rgb:${rgb(c.accent)}; --primary-rgb:${rgb(c.primary)};
  --w-head:${ft.headingWeight}; --w-body:${ft.bodyWeight}; --w-eyebrow:${ft.eyebrowWeight};
  --wm-track:${brand.type.wordmarkTracking}; --eyebrow-track:${brand.type.eyebrowTracking};
  --grain:${(140 / (cfg.scale || 1)).toFixed(2)}px;
}
${css}
.stage{ padding:${SAFE_TOP}px ${GUTTER}px ${padBottom}px; }
</style></head><body>
<div class="frame ${theme}">
  ${photo(f)}
  ${splitPhotos(f)}
  ${ghost}
  <div class="grain"></div>
  <div class="stage ${b.cls}">
    ${chip(brand, cfg, { ...f, theme })}
    <div class="body-area ${b.center ? 'center-block' : ''}"><div class="fitbox">${b.html}</div></div>
  </div>
  ${cfg.guides ? guides(f) : ''}
</div>
<script>
(function(){
  // centred frames sit a touch high: the bottom band belongs to Instagram's reply bar
  var CAP=${fitCap}, ALIGN=${b.cls === 'bottom' ? 1 : 0.45};
  var area=document.querySelector('.body-area'), box=document.querySelector('.fitbox');
  var AH=area.clientHeight;
  function h(z){ box.style.zoom=z; return box.getBoundingClientRect().height; }
  var z;
  if (h(CAP) <= AH+0.5) z=CAP;
  else { var lo=0.38, hi=CAP;
    for (var k=0;k<28;k++){ var m=(lo+hi)/2; if (h(m)<=AH+0.5) lo=m; else hi=m; }
    z=lo; }
  var free=Math.max(0, AH-h(z));
  box.style.marginTop=((free*ALIGN)/z)+'px';
  document.body.dataset.fit=z.toFixed(3);
})();
</script></body></html>`;
}

/* Accept a brand file written for either studio. Carousel-era files name their logo
   variants by this brand's own colours (gold/blue/white/charcoal); stories name them
   semantically. Normalising here means one brand file serves both studios. */
function normalizeBrand(b) {
  const L = b.logo || {};
  b.logo = {
    accent:  L.accent  || L.gold  || L.primary || L.white,
    primary: L.primary || L.blue  || L.accent  || L.dark,
    light:   L.light   || L.white || L.accent,
    dark:    L.dark    || L.charcoal || L.primary,
  };
  const missing = Object.entries(b.logo).filter(([, v]) => !v).map(([k]) => k);
  if (missing.length) throw new Error('brand.logo is missing: ' + missing.join(', '));
  b.type = b.type || {};
  b.type.wordmarkTracking = b.type.wordmarkTracking || '0.40em';
  b.type.eyebrowTracking  = b.type.eyebrowTracking  || '0.28em';
  b.tagline = b.tagline || '';
  return b;
}

function stickerMap(brief, brand) {
  const rows = brief.frames.map((f, i) => {
    const t = f.sticker && f.sticker.type && f.sticker.type !== 'none' ? f.sticker.type : null;
    if (!t) return `| ${String(i+1).padStart(2,'0')} | ${f.type} | — | — |`;
    const midPct = ((STICKER_TOP + STICKER_H / 2) / H * 100).toFixed(0);
    const note = f.sticker.note || '';
    return `| ${String(i+1).padStart(2,'0')} | ${f.type} | **${t}** | centre it **${midPct}% down** the frame — the empty band${note ? '. ' + note : ''} |`;
  }).join('\n');

  const anySticker = brief.frames.some(f => f.sticker && f.sticker.type && f.sticker.type !== 'none');

  return `# Sticker map — ${brief.slug}

The artwork leaves these zones deliberately clear. Add the real Instagram stickers in the
app after uploading — a rendered poll is a picture of a poll; only the real sticker collects
answers, taps and link clicks.

| # | frame | sticker | where |
|---|---|---|---|
${rows}

${anySticker ? `## Placing them
1. Upload the frame, then tap the sticker icon.
2. Drag the sticker so its centre sits at the percentage above — the artwork's empty band.
3. Match the sticker's text to the words already on the frame; don't restate them.
4. For link stickers, shorten the label to 2–3 words — the sticker truncates.
` : 'No interactive stickers in this set.\n'}`;
}

(async () => {
  const brief = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
  const brandFile = path.join(ROOT, 'brands', (brief.brand || 'example') + '.json');
  if (!fs.existsSync(brandFile)) {
    console.error(`No brand file at ${brandFile}. Run: python3 scripts/new_brand.py --help`);
    process.exit(1);
  }
  const brand = normalizeBrand(JSON.parse(fs.readFileSync(brandFile, 'utf8')));
  const css = fs.readFileSync(path.join(ROOT, 'engine.css'), 'utf8');
  const outDir = process.argv[3] || path.join(ROOT, 'out', brief.slug || 'story');
  fs.mkdirSync(outDir, { recursive: true });

  const MASTER = Number(process.env.SCALE || brief.scale || 2);   // 2 -> 2160x3840, true 4K portrait
  const n = brief.frames.length;
  const base = { theme: brief.theme || 'dark', handle: brief.handle,
                 showHandle: brief.showHandle, scale: MASTER };

  const needW = Math.round(W * MASTER);
  for (const f of brief.frames) {
    for (const src of [f.image, ...(f.images || [])].filter(Boolean)) {
      try {
        const d = require('child_process').execSync(
          `python3 -c "from PIL import Image;im=Image.open(r'''${src}''');print(im.size[0],im.size[1])"`,
          { encoding: 'utf8' }).trim().split(' ').map(Number);
        if (d[0] < needW) console.log(`  ! ${src} is ${d[0]}x${d[1]} — under ${needW}px wide, it will be upscaled at ${MASTER}x`);
        if (d[1] / d[0] < 1.4) console.log(`  ! ${src} is ${d[0]}x${d[1]} — wider than 9:16, so it will be cropped hard. Set "focal" to keep the subject.`);
      } catch (e) {}
    }
  }

  const browser = await chromium.launch({ args:['--allow-file-access-from-files','--font-render-hinting=none'] });
  const passes = MASTER === 1 ? [{ scale:1, dir:outDir }]
                              : [{ scale:MASTER, dir:outDir },
                                 { scale:1, dir:path.join(outDir,'instagram-1080') }];
  if (process.env.SHOW_GUIDES) passes.push({ scale:1, dir:path.join(outDir,'guides'), guides:true });

  for (const pass of passes) {
    fs.mkdirSync(pass.dir, { recursive:true });
    const page = await browser.newPage({ viewport:{width:W,height:H}, deviceScaleFactor:pass.scale });
    for (let i=0;i<n;i++){
      const html = buildHTML(brief.frames[i], i, n, brand,
                             { ...base, scale:pass.scale, guides:pass.guides }, css);
      const tmp = path.join(pass.dir, `_f${i+1}.html`);
      fs.writeFileSync(tmp, html);
      await page.goto('file://'+tmp, { waitUntil:'networkidle' });
      await page.waitForTimeout(240);
      await page.screenshot({ path: path.join(pass.dir,
        `${brief.slug||'story'}_${String(i+1).padStart(2,'0')}.png`) });
      fs.unlinkSync(tmp);
      process.stdout.write(`  ${W*pass.scale}x${H*pass.scale}${pass.guides?' (guides)':''}  ${i+1}/${n}\n`);
    }
    await page.close();
  }
  await browser.close();

  fs.writeFileSync(path.join(outDir,'sticker-map.md'), stickerMap(brief, brand));
  fs.writeFileSync(path.join(outDir,'brief.used.json'), JSON.stringify(brief,null,2));
  if (brief.captions) {
    fs.writeFileSync(path.join(outDir,'captions.txt'),
      brief.captions.map((c,i)=>`Frame ${String(i+1).padStart(2,'0')}: ${c}`).join('\n')+'\n');
  }
  console.log('OUT '+outDir);
})();
